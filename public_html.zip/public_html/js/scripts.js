<script>
  function openForm() {
    document.getElementById('form-modal').style.display = 'block';
  }

  function closeForm() {
    document.getElementById('form-modal').style.display = 'none';
  }
</script>
